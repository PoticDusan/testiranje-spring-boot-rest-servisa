insert into `role` (`id`, `name`) values
(1, 'ADMIN'),
(2, 'USER');

insert into `user` (`id`, `username`, `password`, `role_id`) values
(1, 'petar123', '$2a$10$5e3dB36HeRcozRgp8xQfw.tfD3Qsut8xu/NT9g/DSpVKg9Kzuitrq', 1),
(2, 'marko123', '$2a$10$5e3dB36HeRcozRgp8xQfw.tfD3Qsut8xu/NT9g/DSpVKg9Kzuitrq', 2),
(3, 'jovan123', '$2a$10$5e3dB36HeRcozRgp8xQfw.tfD3Qsut8xu/NT9g/DSpVKg9Kzuitrq', 2);

insert into `genre` (`id`, `name`) values
(1, 'Drama'),
(2, 'Thriller'),
(3, 'Comedy'),
(4, 'Action');

insert into `actor` (`id`, `first_name`, `last_name`) values
(1, 'Sean', 'Hayes'),
(2, 'Will', 'Sasso'),
(3, 'Chris', 'Diamantopoulos'),
(4, 'Robert', 'Downey Jr.'),
(5, 'Chris', 'Hemswort'),
(6, 'Mark', 'Ruffalo');

insert into `director` (`id`, `first_name`, `last_name`) values
(1, 'Bobby', 'Farrelly'),
(2, 'Peter', 'Farrelly'),
(3, 'Anthony', 'Russo'),
(4, 'Joe', 'Russo');

insert into `movie` (`id`, `name`, `caption`, `year`, `rating`, `genre_id`) values
(1, 'The Three Stooges', 'While trying to save their childhood orphanage, Moe, Larry and Curly inadvertently stumble into a murder plot and wind up starring in a reality television show.', 2012, 5.1, 3),
(2, 'Avengers: Endgame', 'After the devastating events of Avengers: Infinity War (2018), the universe is in ruins. With the help of remaining allies, the Avengers assemble once more in order to reverse Thanos actions and restore balance to the universe.', 2019, 8.7, 4);

insert into `movie_cast` (`movie_id`, `actor_id`) values
(1, 1),
(1, 2),
(1, 3),
(2, 4),
(2, 5),
(2, 6);

insert into `movie_director` (`movie_id`, `director_id`) values
(1, 1),
(1, 2),
(2, 3),
(2, 4);

insert into `user_favorite` (`user_id`, `movie_id`) values
(2, 1),
(2, 2),
(3, 1);