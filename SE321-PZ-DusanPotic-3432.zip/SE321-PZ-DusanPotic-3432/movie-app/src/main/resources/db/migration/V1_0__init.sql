create table `role` (
	id int not null auto_increment,
	name varchar(20) not null,
	primary key (id)
);

create table `user` (
	id int not null auto_increment,
	username varchar(50) not null,
	`password` varchar(100) not null,
	role_id int not null,
	primary key (id)
);

create table `genre` (
	id int not null auto_increment,
	name varchar(100) not null,
	primary key (id)
);

create table `actor` (
	id int not null auto_increment,
	first_name varchar(50) not null,
	last_name varchar(50) not null,
	primary key (id)
);

create table `director` (
	id int not null auto_increment,
	first_name varchar(50) not null,
	last_name varchar(50) not null,
	primary key (id)
);

create table `movie` (
    id int not null auto_increment,
    name varchar(100) not null,
    caption varchar(500) not null,
    year smallint not null,
    rating float not null,
    genre_id int not null,
    primary key (id)

);

create table `movie_cast` (
    movie_id int not null,
    actor_id int not null,
    primary key (movie_id, actor_id)
);

create table `movie_director` (
    movie_id int not null,
    director_id int not null,
    primary key (movie_id, director_id)
);

create table `user_favorite` (
    user_id int not null,
    movie_id int not null,
    primary key (user_id, movie_id)
);