alter table `user` add constraint fk_role foreign key (role_id) references `role`(id);
alter table `movie` add constraint fk_genre foreign key (genre_id) references `genre`(id);
alter table `movie_cast` add constraint fk_movie_cast foreign key (movie_id) references `movie`(id);
alter table `movie_cast` add constraint fk_actor_cast foreign key (actor_id) references `actor`(id);
alter table `movie_director` add constraint fk_movie_dir foreign key (movie_id) references `movie`(id);
alter table `movie_director` add constraint fk_actor_dir foreign key (director_id) references `director`(id);
alter table `user_favorite` add constraint fk_user foreign key (user_id) references `user`(id);
alter table `user_favorite` add constraint fk_movie_fav foreign key (movie_id) references `movie`(id);
