package com.movieapp.service;

import com.movieapp.entity.Director;
import com.movieapp.entity.Movie;
import com.movieapp.entity.MovieDirector;
import com.movieapp.exception.DirectorAlreadyDirectsException;
import com.movieapp.exception.DirectorNotFoundException;
import com.movieapp.exception.MovieDirectorNotFoundException;
import com.movieapp.exception.MovieNotFoundException;
import com.movieapp.model.MovieDirectorModel;
import com.movieapp.repository.MovieDirectorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class MovieDirectorService {

    @Autowired
    private MovieDirectorRepository repo;

    @Autowired
    private MovieService movieService;

    @Autowired
    private DirectorService directorService;

    public MovieDirector getByMovieAndDirector(Movie movie, Director director) {
        Optional<MovieDirector> omd = repo.findByMovieAndDirector(movie, director);
        if(!omd.isPresent()) throw new MovieDirectorNotFoundException("Director with id " + director.getId() + " is not the director for movie with id " + movie.getId());
        return omd.get();
    }

    public MovieDirector insert(Movie movie, Director director) {
        Optional<MovieDirector> omd = repo.findByMovieAndDirector(movie, director);
        if(omd.isPresent()) throw new DirectorAlreadyDirectsException("Director with id " + director.getId() + " is already the director for movie with id " + movie.getId());
        MovieDirector md = new MovieDirector(movie, director);
        return repo.save(md);
    }

    public MovieDirector insert(Long movieId, MovieDirectorModel movieDirectorModel) {
        Movie m = movieService.getMovie(movieId);
        Director d = directorService.getDirector(movieDirectorModel.getDirectorId());
        if(m == null) throw new MovieNotFoundException("Movie with id " + movieId + " not found");
        if(d == null) throw new DirectorNotFoundException("Director with id " + movieDirectorModel.getDirectorId() + " not found");
        return insert(m, d);
    }

    public Movie remove(Long movieId, MovieDirectorModel movieDirectorModel) {
        Movie m = movieService.getMovie(movieId);
        Director d = directorService.getDirector(movieDirectorModel.getDirectorId());
        if(m == null) throw new MovieNotFoundException("Movie with id " + movieId + " not found");
        if(d == null) throw new DirectorNotFoundException("Director with id " + movieDirectorModel.getDirectorId() + " not found");
        MovieDirector md = getByMovieAndDirector(m, d);
        repo.delete(md);
        return m;
    }
}
