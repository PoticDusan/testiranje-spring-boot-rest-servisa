package com.movieapp.exception;

public class MovieNotInFavoriteListException extends RuntimeException {
    public MovieNotInFavoriteListException(String message) {
        super(message);
    }
}
