package com.movieapp.exception;

public class MovieDirectorNotFoundException extends RuntimeException {
    public MovieDirectorNotFoundException(String message) {
        super(message);
    }
}
