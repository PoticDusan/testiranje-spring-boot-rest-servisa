package com.movieapp.controller;

import com.movieapp.config.Path;
import com.movieapp.entity.Genre;
import com.movieapp.service.GenreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(Path.API)
public class GenreController {

    @Autowired
    private GenreService genreService;

    @GetMapping(Path.GENRES)
    public List<Genre> getAllGenres() {
        return genreService.getGenres();
    }

    @GetMapping(Path.GENRE_ID)
    public Genre getGenre(@PathVariable("id") Long id) {
        return genreService.getGenre(id);
    }

    @PostMapping(Path.GENRE)
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<Genre> createGenre(@RequestBody Genre genre) {
        return new ResponseEntity<>(genreService.insertGenre(genre), HttpStatus.CREATED);
    }

    @PutMapping(Path.GENRE_ID)
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<Genre> updateGenre(@PathVariable("id") Long id, @RequestBody Genre genre) {
        return ResponseEntity.ok(genreService.updateGenre(id, genre));
    }
}
