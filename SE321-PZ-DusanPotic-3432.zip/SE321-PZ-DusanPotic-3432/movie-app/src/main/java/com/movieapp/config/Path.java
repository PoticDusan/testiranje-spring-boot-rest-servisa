package com.movieapp.config;

public class Path {

    public static final String API = "/api";

    private static final String SEPARATOR = "/";
    private static final String ID = "{id}";

    // Swagger
    public static final String API_DOCS = "/v2/api-docs";
    public static final String SWAGGER = "/swagger*/**";
    public static final String WEBJARS = "/webjars/**";
    public static final String CONFIGURATION = "/configuration/**";

    // Auth
    public static final String AUTH = "/auth";
    public static final String REGISTER = "/register";

    public static final String API_AUTH = API + AUTH;
    public static final String API_REGISTER = API + REGISTER;

    // Actor
    public static final String ACTORS = "/actors";
    public static final String ACTOR = "/actor";
    public static final String ACTOR_ID = ACTOR + SEPARATOR + ID;
    public static final String ACTOR_MOVIES = ACTOR_ID + SEPARATOR + "movies";

    // Director
    public static final String DIRECTORS = "/directors";
    public static final String DIRECTOR = "/director";
    public static final String DIRECTOR_ID = DIRECTOR + SEPARATOR + ID;

    // Genre
    public static final String GENRES = "/genres";
    public static final String GENRE = "/genre";
    public static final String GENRE_ID = GENRE + SEPARATOR + ID;

    // Movie
    public static final String MOVIES = "/movies";
    public static final String MOVIE = "/movie";
    public static final String MOVIE_ID = MOVIE + SEPARATOR + ID;
    public static final String MOVIE_FROM_YEAR = MOVIE + "/year/{year}";
    public static final String MOVIE_CAST = MOVIE_ID + SEPARATOR + "cast";
    public static final String MOVIE_DIRECTORS = MOVIE_ID + SEPARATOR + "directors";
    public static final String MOVIE_DIRECTOR = MOVIE_ID + SEPARATOR + "director";
    public static final String MOVIE_ACTOR = MOVIE_ID + SEPARATOR + "actor";

    // User
    public static final String USERS = "/users";
    private static final String USER = "/user";
    public static final String USER_ID = USER + SEPARATOR + ID;
    public static final String USER_ID_FAVORITE = USER_ID + SEPARATOR + "favorite";
    public static final String USER_FAVORITE = USER + SEPARATOR + "favorite";
    public static final String USER_PASSWORD = USER + SEPARATOR + "password";

}