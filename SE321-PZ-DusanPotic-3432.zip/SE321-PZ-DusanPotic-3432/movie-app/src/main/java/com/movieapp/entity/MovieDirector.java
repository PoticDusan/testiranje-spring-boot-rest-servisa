package com.movieapp.entity;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "movie_director")
@IdClass(MovieDirectorPK.class)
public class MovieDirector implements Serializable {

    @Id
    @Column(name = "movie_id")
    private Long movieId;

    @Id
    @Column(name = "director_id")
    private Long directorId;

    @ManyToOne
    @JoinColumn(name = "movie_id", referencedColumnName = "id", insertable = false, updatable = false)
    private Movie movie;

    @ManyToOne
    @JoinColumn(name = "director_id", referencedColumnName = "id", insertable = false, updatable = false)
    private Director director;

    public MovieDirector() {
    }

    public MovieDirector(Movie movie, Director director) {
        setMovie(movie);
        setDirector(director);
    }

    public MovieDirector create(Movie movie, Director director) {
        return new MovieDirector(movie, director);
    }

    public Movie getMovie() {
        return movie;
    }

    public void setMovie(Movie movie) {
        this.movieId = movie.getId();
        this.movie = movie;
    }

    public Director getDirector() {
        return director;
    }

    public void setDirector(Director director) {
        this.directorId = director.getId();
        this.director = director;
    }

    public Long getMovieId() {
        return movieId;
    }

    public Long getDirectorId() {
        return directorId;
    }

    @Override
    public String toString() {
        return "MovieDirector {" +
                "movie=" + movie +
                ", director=" + director +
                '}';
    }
}
