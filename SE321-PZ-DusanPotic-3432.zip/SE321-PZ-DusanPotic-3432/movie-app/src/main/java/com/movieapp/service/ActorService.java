package com.movieapp.service;

import com.movieapp.entity.Actor;
import com.movieapp.entity.Movie;
import com.movieapp.exception.ActorNotFoundException;
import com.movieapp.repository.ActorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ActorService {

    @Autowired
    private ActorRepository repo;

    public List<Actor> getActors() {
        return repo.findAll();
    }

    public Actor getActor(Long id) {
        return repo.findById(id).orElse(null);
    }

    public List<Movie> getActorMovies(Long id) { return repo.findActorMovies(id); }

    public Actor insetActor(Actor actor) { return repo.save(actor); }

    public Actor updateActor(Long id, Actor actor) {
        Actor a = getActor(id);
        if (a == null) throw new ActorNotFoundException("Actor with id " + id + " not found");
        if(actor.getFirstName() != null) a.setFirstName(actor.getFirstName());
        if(actor.getLastName() != null) a.setLastName(actor.getLastName());
        return repo.save(a);
    }
}
