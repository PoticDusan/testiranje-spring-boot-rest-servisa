package com.movieapp.model;

public class MovieDirectorModel {

    private Long directorId;

    public MovieDirectorModel() {
    }

    public MovieDirectorModel(Long directorId) {
        this.directorId = directorId;
    }

    public Long getDirectorId() {
        return directorId;
    }

    public void setDirectorId(Long directorId) {
        this.directorId = directorId;
    }
}
