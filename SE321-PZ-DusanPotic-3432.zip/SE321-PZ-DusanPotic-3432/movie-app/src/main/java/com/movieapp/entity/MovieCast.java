package com.movieapp.entity;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "movie_cast")
@IdClass(MovieCastPK.class)
public class MovieCast implements Serializable {

    @Id
    @Column(name = "movie_id")
    private Long movieId;

    @Id
    @Column(name = "actor_id")
    private Long actorId;

    @ManyToOne
    @JoinColumn(name = "movie_id", referencedColumnName = "id", insertable = false, updatable = false)
    private Movie movie;

    @ManyToOne
    @JoinColumn(name = "actor_id", referencedColumnName = "id", insertable = false, updatable = false)
    private Actor actor;

    public MovieCast() {
    }

    public MovieCast(Movie movie, Actor actor) {
        setMovie(movie);
        setActor(actor);
    }

    public Movie getMovie() {
        return movie;
    }

    public void setMovie(Movie movie) {
        this.movieId = movie.getId();
        this.movie = movie;
    }

    public Actor getActor() {
        return actor;
    }

    public void setActor(Actor actor) {
        this.actorId = actor.getId();
        this.actor = actor;
    }

    public Long getMovieId() {
        return movieId;
    }

    public Long getActorId() {
        return actorId;
    }

    @Override
    public String toString() {
        return "MovieCast{" +
                "movie=" + movie +
                ", actor=" + actor +
                '}';
    }
}
