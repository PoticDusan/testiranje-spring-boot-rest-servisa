package com.movieapp.service;

import com.movieapp.entity.Genre;
import com.movieapp.exception.GenreNotFoundException;
import com.movieapp.repository.GenreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GenreService {

    @Autowired
    private GenreRepository repo;

    public List<Genre> getGenres() {
        return repo.findAll();
    }

    public Genre getGenre(Long id) {
        return repo.findById(id).orElse(null);
    }

    public Genre insertGenre(Genre genre) { return repo.save(genre); }

    public Genre updateGenre(Long id, Genre genre) {
        Genre g = getGenre(id);
        if (g == null) throw new GenreNotFoundException("Genre with id " + id + " not found");
        genre.setId(g.getId());
        return repo.save(genre);
    }
}
