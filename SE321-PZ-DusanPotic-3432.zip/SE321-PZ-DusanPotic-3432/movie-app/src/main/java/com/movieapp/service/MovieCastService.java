package com.movieapp.service;

import com.movieapp.entity.Actor;
import com.movieapp.entity.Movie;
import com.movieapp.entity.MovieCast;
import com.movieapp.exception.ActorAlreadyInMovieException;
import com.movieapp.exception.ActorNotFoundException;
import com.movieapp.exception.MovieCastNotFoundException;
import com.movieapp.exception.MovieNotFoundException;
import com.movieapp.model.MovieCastModel;
import com.movieapp.repository.MovieCastRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class MovieCastService {

    @Autowired
    private MovieCastRepository repo;

    @Autowired
    private MovieService movieService;

    @Autowired
    private ActorService actorService;

    public MovieCast getByMovieAndActor(Movie movie, Actor actor) {
        Optional<MovieCast> omc = repo.findByMovieAndActor(movie, actor);
        if(!omc.isPresent()) throw new MovieCastNotFoundException("Actor with id " + actor.getId() + " is not acting in movie with id " + movie.getId());
        return omc.get();
    }

    private MovieCast insert(Movie movie, Actor actor) {
        Optional<MovieCast> omc = repo.findByMovieAndActor(movie, actor);
        if(omc.isPresent()) throw new ActorAlreadyInMovieException("Actor with id " + actor.getId() + " is already acting in movie with id " + movie.getId());
        MovieCast mc = new MovieCast(movie, actor);
        return repo.save(mc);
    }

    public MovieCast insert(Long movieId, MovieCastModel movieCastModel) {
        Movie m = movieService.getMovie(movieId);
        Actor a = actorService.getActor(movieCastModel.getActorId());
        if(m == null) throw new MovieNotFoundException("Movie with id " + movieId + " not found");
        if(a == null) throw new ActorNotFoundException("Actor with id " + movieCastModel.getActorId() + " not found");
        return insert(m, a);
    }

    public Movie remove(Long movieId, MovieCastModel movieCastModel) {
        Movie m = movieService.getMovie(movieId);
        Actor a = actorService.getActor(movieCastModel.getActorId());
        if(m == null) throw new MovieNotFoundException("Movie with id " + movieId + " not found");
        if(a == null) throw new ActorNotFoundException("Actor with id " + movieCastModel.getActorId() + " not found");
        MovieCast mc = getByMovieAndActor(m, a);
        repo.delete(mc);
        return m;
    }

}
