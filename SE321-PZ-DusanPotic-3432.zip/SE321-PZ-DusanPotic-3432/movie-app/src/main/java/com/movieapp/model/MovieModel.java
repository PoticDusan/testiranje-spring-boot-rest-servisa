package com.movieapp.model;

public class MovieModel {

    private Long id;
    private String name;
    private String caption;
    private Integer year;
    private Float rating;
    private Long genreId;

    public MovieModel() {
    }

    public MovieModel(String name, String caption, Integer year, Float rating, Long genreId) {
        this.name = name;
        this.caption = caption;
        this.year = year;
        this.rating = rating;
        this.genreId = genreId;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public Float getRating() {
        return rating;
    }

    public void setRating(Float rating) {
        this.rating = rating;
    }

    public Long getGenreId() {
        return genreId;
    }

    public void setGenreId(Long genreId) {
        this.genreId = genreId;
    }
}
