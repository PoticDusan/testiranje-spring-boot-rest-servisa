package com.movieapp.repository;

import com.movieapp.entity.Director;
import com.movieapp.entity.Movie;
import com.movieapp.entity.MovieDirector;
import com.movieapp.entity.MovieDirectorPK;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface MovieDirectorRepository extends JpaRepository<MovieDirector, MovieDirectorPK> {

    @Query(value = "select md from MovieDirector md, Movie m, Director d where md.movie = m and md.director = d and m = :movie and d = :director")
    Optional<MovieDirector> findByMovieAndDirector(@Param("movie") Movie movie, @Param("director") Director director);

}
