package com.movieapp.service;

import com.movieapp.entity.Movie;
import com.movieapp.entity.User;
import com.movieapp.entity.UserFavorite;
import com.movieapp.exception.MovieAlreadyInFavoriteException;
import com.movieapp.exception.MovieNotInFavoriteListException;
import com.movieapp.repository.UserFavoriteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserFavoriteService {

    @Autowired
    private UserFavoriteRepository repo;

    public UserFavorite insert(User user, Movie movie) {
        Optional<UserFavorite> ouf = repo.findByUserAndMovie(user, movie);
        if(ouf.isPresent()) throw new MovieAlreadyInFavoriteException("Movie with id " + movie.getId() + " is already in your favorite list");
        UserFavorite uf = new UserFavorite(user, movie);
        return repo.save(uf);
    }

    public UserFavorite getByUserAndMovie(User user, Movie movie) {
        Optional<UserFavorite> ouf = repo.findByUserAndMovie(user, movie);
        if(!ouf.isPresent()) throw new MovieNotInFavoriteListException("Movie with id " + movie.getId() + " is not in your favorite list");
        return ouf.get();
    }

    public Movie remove(UserFavorite uf) {
        repo.delete(uf);
        return uf.getMovie();
    }
}
