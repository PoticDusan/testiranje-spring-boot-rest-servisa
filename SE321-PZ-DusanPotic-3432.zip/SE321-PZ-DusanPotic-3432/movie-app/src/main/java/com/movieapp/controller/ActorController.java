package com.movieapp.controller;

import com.movieapp.config.Path;
import com.movieapp.entity.Actor;
import com.movieapp.entity.Movie;
import com.movieapp.service.ActorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(Path.API)
public class ActorController {

    @Autowired
    private ActorService actorService;

    @GetMapping(Path.ACTORS)
    public List<Actor> getAllActors() {
        return actorService.getActors();
    }

    @GetMapping(Path.ACTOR_ID)
    public Actor getActor(@PathVariable("id") Long id) {
        return actorService.getActor(id);
    }

    @GetMapping(Path.ACTOR_MOVIES)
    public List<Movie> getActorMovies(@PathVariable("id") Long id) {
        return actorService.getActorMovies(id);
    }

    @PostMapping(Path.ACTOR)
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<Actor> createActor(@RequestBody Actor actor) {
        return new ResponseEntity<>(actorService.insetActor(actor), HttpStatus.CREATED);
    }

    @PutMapping(Path.ACTOR_ID)
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<Actor> updateActor(@PathVariable("id") Long id, @RequestBody Actor actor) {
        return ResponseEntity.ok(actorService.updateActor(id, actor));
    }

}
