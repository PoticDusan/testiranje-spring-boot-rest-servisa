package com.movieapp.entity;


import java.io.Serializable;
import java.util.Objects;

public class MovieDirectorPK implements Serializable {

    private Long movieId;
    private Long directorId;

    public MovieDirectorPK() {
    }

    public MovieDirectorPK(Long movieId, Long directorId) {
        this.movieId = movieId;
        this.directorId = directorId;
    }

    public Long getMovieId() {
        return movieId;
    }

    public void setMovieId(Long movieId) {
        this.movieId = movieId;
    }

    public Long getDirectorId() {
        return directorId;
    }

    public void setDirectorId(Long directorId) {
        this.directorId = directorId;
    }

    @Override
    public int hashCode() {
        return Objects.hash(movieId, directorId);
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof MovieDirector)) {
            return false;
        }

        MovieDirector md = (MovieDirector) obj;
        return Objects.equals(movieId, md.getMovie().getId()) && Objects.equals(directorId, md.getDirector().getId());
    }
}
