package com.movieapp.exception;

public class MovieCastNotFoundException extends RuntimeException {
    public MovieCastNotFoundException(String message) {
        super(message);
    }
}
