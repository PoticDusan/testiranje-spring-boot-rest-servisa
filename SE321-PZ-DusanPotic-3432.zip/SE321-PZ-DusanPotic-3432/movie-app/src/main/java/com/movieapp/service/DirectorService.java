package com.movieapp.service;

import com.movieapp.entity.Director;
import com.movieapp.exception.DirectorNotFoundException;
import com.movieapp.repository.DirectorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DirectorService {

    @Autowired
    private DirectorRepository repo;

    public List<Director> getDirectors() { return repo.findAll(); }

    public Director getDirector(Long id) { return repo.findById(id).orElse(null); }

    public Director insertDirector(Director director) { return repo.save(director); }

    public Director updateDirector(Long id, Director director) {
        Director d = getDirector(id);
        if (d == null) throw new DirectorNotFoundException("Director with id " + id + " not found");
        director.setId(d.getId());
        return repo.save(director);
    }
}
