package com.movieapp.exception;

public class ActorAlreadyInMovieException extends RuntimeException {
    public ActorAlreadyInMovieException(String message) {
        super(message);
    }
}
