package com.movieapp.controller;

import com.movieapp.config.Path;
import com.movieapp.entity.Director;
import com.movieapp.service.DirectorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(Path.API)
public class DirectorController {

    @Autowired
    private DirectorService directorService;

    @GetMapping(Path.DIRECTORS)
    public List<Director> getAllDirectors() {
        return directorService.getDirectors();
    }

    @GetMapping(Path.DIRECTOR_ID)
    public Director getDirector(@PathVariable("id") Long id) {
        return directorService.getDirector(id);
    }

    @PostMapping(Path.DIRECTOR)
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<Director> createDirector(@RequestBody Director director) {
        return new ResponseEntity<>(directorService.insertDirector(director), HttpStatus.CREATED);
    }

    @PutMapping(Path.DIRECTOR_ID)
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<Director> updateDirector(@PathVariable("id") Long id, @RequestBody Director director) {
        return ResponseEntity.ok(directorService.updateDirector(id, director));
    }
}
