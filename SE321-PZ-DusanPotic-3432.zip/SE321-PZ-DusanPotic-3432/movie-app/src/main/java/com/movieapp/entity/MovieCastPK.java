package com.movieapp.entity;

import java.io.Serializable;
import java.util.Objects;

public class MovieCastPK implements Serializable {

    private Long movieId;
    private Long actorId;

    public MovieCastPK() {
    }

    public MovieCastPK(Long movieId, Long actorId) {
        this.movieId = movieId;
        this.actorId = actorId;
    }

    public Long getMovieId() {
        return movieId;
    }

    public void setMovieId(Long movieId) {
        this.movieId = movieId;
    }

    public Long getActorId() {
        return actorId;
    }

    public void setActorId(Long actorId) {
        this.actorId = actorId;
    }

    @Override
    public int hashCode() {
        return Objects.hash(movieId, actorId);
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof MovieCast)) {
            return false;
        }

        MovieCast mc = (MovieCast) obj;
        return Objects.equals(movieId, mc.getMovie().getId()) && Objects.equals(actorId, mc.getActor().getId());
    }
}
