package com.movieapp.model;

public class MovieCastModel {

    private Long actorId;

    public MovieCastModel() {
    }

    public MovieCastModel(Long actorId) {
        this.actorId = actorId;
    }

    public Long getActorId() {
        return actorId;
    }

    public void setActorId(Long actorId) {
        this.actorId = actorId;
    }
}
