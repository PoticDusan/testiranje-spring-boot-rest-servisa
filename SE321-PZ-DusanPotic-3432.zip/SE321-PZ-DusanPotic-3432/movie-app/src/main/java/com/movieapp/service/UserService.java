package com.movieapp.service;

import com.movieapp.entity.UserFavorite;
import com.movieapp.exception.InvalidOldPasswordException;
import com.movieapp.exception.MovieNotFoundException;
import com.movieapp.model.UserRequest;
import com.movieapp.entity.Movie;
import com.movieapp.entity.Role;
import com.movieapp.entity.User;
import com.movieapp.exception.UserExistsException;
import com.movieapp.exception.UserNotFoundException;
import com.movieapp.model.MovieFavRequest;
import com.movieapp.model.PasswordChangeModel;
import com.movieapp.repository.MovieRepository;
import com.movieapp.repository.UserRepository;
import com.movieapp.security.LoginUserDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService implements UserDetailsService {

    @Autowired
    private UserRepository userRepo;

    @Autowired
    private MovieRepository movieRepo;

    @Autowired
    private UserFavoriteService userFavoriteService;

    @Autowired
    private PasswordEncoder bcryptEncoder;

    public List<User> getUsers() {
        return userRepo.findAll();
    }

    public User getUser(Long id) {
        return userRepo.findById(id).orElse(null);
    }

    public List<Movie> getUserFavoriteMovies(Long id) {
        return userRepo.findUserFavoriteMovies(id);
    }

    public User getByUsername(String username) {
        Optional<User> u = userRepo.findByUsername(username);
        if(!u.isPresent()) throw new UserNotFoundException("Could not find user with username " + username);
        return u.get();
    }

    @Override
    public UserDetails loadUserByUsername(String s) {
        Optional<User> u = userRepo.findByUsername(s);
        if(!u.isPresent()) throw new UsernameNotFoundException("Could not find user with username " + s);
        return new LoginUserDetails(u.get());
    }

    public User insertUser(UserRequest userRequest) {
        Optional<User> ou = userRepo.findByUsername(userRequest.getUsername());
        if(ou.isPresent()) throw new UserExistsException("User with username " + userRequest.getUsername() + " already exists");
        User u = new User();
        u.setUsername(userRequest.getUsername());
        u.setPassword(bcryptEncoder.encode(userRequest.getPassword()));
        u.setRole(new Role(2L, "USER"));
        return userRepo.save(u);
    }

    public Movie insertUserFavoriteMovie(User user, MovieFavRequest movieRequest) {
        Optional<Movie> om = movieRepo.findById(movieRequest.getId());
        if(!om.isPresent()) throw new MovieNotFoundException("Movie with id " + movieRequest.getId() + " not found.");
        UserFavorite uf = userFavoriteService.insert(user, om.get());
        return uf.getMovie();
    }

    public Movie removeFavoriteMovie(User user, MovieFavRequest movieRequest) {
        Optional<Movie> om = movieRepo.findById(movieRequest.getId());
        if(!om.isPresent()) throw new MovieNotFoundException("Movie with id " + movieRequest.getId() + " not found.");
        UserFavorite uf = userFavoriteService.getByUserAndMovie(user, om.get());
        return userFavoriteService.remove(uf);
    }

    public User updateUser(Long id, User user) {
        User u = getUser(id);
        if(u == null) throw new UserNotFoundException("User with id " + id + " not found");
        if(user.getUsername() != null) u.setUsername(user.getUsername());
        if(user.getPassword() != null) u.setPassword(bcryptEncoder.encode(user.getPassword()));
        return userRepo.save(u);
    }

    public User changePassword(User user, PasswordChangeModel passwordChangeModel) {
        if(!bcryptEncoder.matches(passwordChangeModel.getOldPassword(), user.getPassword()))
            throw new InvalidOldPasswordException("Old password does not match for user with id " + user.getId());
        user.setPassword(bcryptEncoder.encode(passwordChangeModel.getNewPassword()));
        return userRepo.save(user);
    }
}
