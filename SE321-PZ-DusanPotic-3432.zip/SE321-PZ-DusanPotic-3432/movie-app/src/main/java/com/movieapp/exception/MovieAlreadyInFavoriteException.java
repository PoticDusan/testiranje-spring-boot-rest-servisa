package com.movieapp.exception;

public class MovieAlreadyInFavoriteException extends RuntimeException {
    public MovieAlreadyInFavoriteException(String message) {
        super(message);
    }
}
