package com.movieapp.repository;

import com.movieapp.entity.Actor;
import com.movieapp.entity.Movie;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ActorRepository extends JpaRepository<Actor, Long> {
    @Query(value = "select m from Movie m, MovieCast mc, Actor a where mc.movie = m and mc.actor = a and a.id = :actorId")
    List<Movie> findActorMovies(@Param("actorId") Long id);
}
