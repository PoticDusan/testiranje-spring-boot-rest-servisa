package com.movieapp.entity;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "user_favorite")
@IdClass(UserFavoritePK.class)
public class UserFavorite implements Serializable {

    @Id
    @Column(name = "user_id")
    private Long userId;

    @Id
    @Column(name = "movie_id")
    private Long movieId;

    @ManyToOne
    @JoinColumn(name = "user_id", referencedColumnName = "id", insertable = false, updatable = false)
    private User user;

    @ManyToOne
    @JoinColumn(name = "movie_id", referencedColumnName = "id", insertable = false, updatable = false)
    private Movie movie;

    public UserFavorite() {
    }

    public UserFavorite(User user, Movie movie) {
        setUser(user);
        setMovie(movie);
    }

    public UserFavorite create(User user, Movie movie) {
        return new UserFavorite(user, movie);
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.userId = user.getId();
        this.user = user;
    }

    public Movie getMovie() {
        return movie;
    }

    public void setMovie(Movie movie) {
        this.movieId = movie.getId();
        this.movie = movie;
    }

    public Long getUserId() {
        return userId;
    }

    public Long getMovieId() {
        return movieId;
    }

    @Override
    public String toString() {
        return "UserFavorite{" +
                "user=" + user +
                ", movie=" + movie +
                '}';
    }
}
