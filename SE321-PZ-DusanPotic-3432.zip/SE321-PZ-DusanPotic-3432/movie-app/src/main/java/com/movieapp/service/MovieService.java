package com.movieapp.service;

import com.movieapp.entity.Actor;
import com.movieapp.entity.Director;
import com.movieapp.entity.Genre;
import com.movieapp.entity.Movie;
import com.movieapp.exception.GenreNotFoundException;
import com.movieapp.exception.MovieNotFoundException;
import com.movieapp.model.MovieCastModel;
import com.movieapp.model.MovieDirectorModel;
import com.movieapp.model.MovieModel;
import com.movieapp.repository.MovieRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MovieService {

    @Autowired
    private MovieRepository repo;

    @Autowired
    private GenreService genreService;

    @Autowired
    private MovieDirectorService movieDirectorService;

    @Autowired
    private MovieCastService movieCastService;

    public List<Movie> getMovies() {
        return repo.findAll();
    }

    public Movie getMovie(Long id) {
        return repo.findById(id).orElse(null);
    }

    public List<Movie> getMoviesFromYear(Integer year) {
        return repo.findByYear(year);
    }

    public List<Actor> getCast(Long id) { return repo.findActors(id); }

    public List<Director> getDirectors(Long id) { return repo.findDirectors(id); }

    public Movie insertMovie(MovieModel movieModel) {
        Genre g = genreService.getGenre(movieModel.getGenreId());
        if(g == null) throw new GenreNotFoundException("Genre with ID " + movieModel.getGenreId() + " not found");
        Movie m = new Movie(movieModel.getName(), movieModel.getCaption(), movieModel.getYear(), movieModel.getRating());
        m.setGenre(g);
        return repo.save(m);
    }

    public Movie insertMovieDirector(Long movieId, MovieDirectorModel movieDirectorModel) {
        return movieDirectorService.insert(movieId, movieDirectorModel).getMovie();
    }

    public Movie removeMovieDirector(Long movieId, MovieDirectorModel movieDirectorModel) {
        return movieDirectorService.remove(movieId, movieDirectorModel);
    }

    public Movie insertMovieActor(Long movieId, MovieCastModel movieCastModel) {
        return movieCastService.insert(movieId, movieCastModel).getMovie();
    }

    public Movie removeMovieActor(Long movieId, MovieCastModel movieCastModel) {
        return movieCastService.remove(movieId, movieCastModel);
    }

    public Movie updateMovie(Long movieId, Movie movie) {
        Movie m = getMovie(movieId);
        if (m == null) throw new MovieNotFoundException("Movie with id " + movieId + " not found");
        if(movie.getName() != null) m.setName(movie.getName());
        if(movie.getCaption() != null) m.setCaption(movie.getCaption());
        if(movie.getYear() != null) m.setYear(movie.getYear());
        if(movie.getRating() != null) m.setRating(movie.getRating());
        return repo.save(m);
    }
}
