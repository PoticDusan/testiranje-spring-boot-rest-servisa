package com.movieapp.repository;

import com.movieapp.entity.Movie;
import com.movieapp.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByUsername(String username);

    @Query(value = "select m from Movie m, UserFavorite uf, User u where uf.user = u and uf.movie = m and u.id = :userId")
    List<Movie> findUserFavoriteMovies(@Param("userId") Long id);
}