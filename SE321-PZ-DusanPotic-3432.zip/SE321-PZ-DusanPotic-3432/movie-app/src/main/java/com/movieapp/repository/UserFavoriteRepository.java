package com.movieapp.repository;

import com.movieapp.entity.Movie;
import com.movieapp.entity.User;
import com.movieapp.entity.UserFavorite;
import com.movieapp.entity.UserFavoritePK;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface UserFavoriteRepository extends JpaRepository<UserFavorite, UserFavoritePK> {

    @Query(value = "select uf from UserFavorite uf, User u, Movie m where uf.user = u and uf.movie = m and u = :user and m = :movie")
    Optional<UserFavorite> findByUserAndMovie(@Param("user") User user, @Param("movie") Movie movie);
}
