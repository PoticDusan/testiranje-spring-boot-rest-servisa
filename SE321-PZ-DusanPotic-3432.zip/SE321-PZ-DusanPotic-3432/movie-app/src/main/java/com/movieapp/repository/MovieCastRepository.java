package com.movieapp.repository;

import com.movieapp.entity.Actor;
import com.movieapp.entity.Movie;
import com.movieapp.entity.MovieCast;
import com.movieapp.entity.MovieCastPK;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface MovieCastRepository extends JpaRepository<MovieCast, MovieCastPK> {

    @Query(value = "select mc from MovieCast mc, Movie m, Actor a where mc.movie = m and mc.actor = a and m = :movie and a = :actor")
    Optional<MovieCast> findByMovieAndActor(@Param("movie") Movie movie, @Param("actor") Actor actor);

}
