package com.movieapp.repository;

import com.movieapp.entity.Actor;
import com.movieapp.entity.Director;
import com.movieapp.entity.Movie;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface MovieRepository extends JpaRepository<Movie, Long> {

    List<Movie> findByYear(Integer year);

    @Query(value = "select a from Actor a, MovieCast mc, Movie m where mc.actor = a and mc.movie = m and m.id = :movieId")
    List<Actor> findActors(@Param("movieId") Long id);

    @Query(value = "select d from Director d, MovieDirector md, Movie m where md.director = d and md.movie = m and m.id = :movieId")
    List<Director> findDirectors(@Param("movieId") Long id);
}
