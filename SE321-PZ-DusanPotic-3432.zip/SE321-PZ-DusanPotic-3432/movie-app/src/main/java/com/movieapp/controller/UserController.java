package com.movieapp.controller;

import com.movieapp.config.Path;
import com.movieapp.entity.Movie;
import com.movieapp.entity.User;
import com.movieapp.model.MovieFavRequest;
import com.movieapp.model.PasswordChangeModel;
import com.movieapp.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(Path.API)
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping(Path.USERS)
    @PreAuthorize("hasAuthority('ADMIN')")
    public List<User> getAllUsers() {
        return userService.getUsers();
    }

    @GetMapping(Path.USER_ID)
    @PreAuthorize("hasAuthority('ADMIN')")
    public User getUser(@PathVariable("id") Long id) {
        return userService.getUser(id);
    }


    @GetMapping(Path.USER_ID_FAVORITE)
    @PreAuthorize("hasAuthority('ADMIN')")
    public List<Movie> getUserFavoriteMovies(@PathVariable("id") Long id) {
        return userService.getUserFavoriteMovies(id);
    }

    @GetMapping(Path.USER_FAVORITE)
    //@PreAuthorize("hasAnyAuthority('ADMIN', 'USER')")
    public List<Movie> getUserFavoriteMovies() {
        Authentication loggedInUser = SecurityContextHolder.getContext().getAuthentication();
        String username = loggedInUser.getName();
        User user = userService.getByUsername(username);
        return userService.getUserFavoriteMovies(user.getId());
    }

    @PostMapping(Path.USER_FAVORITE)
    @PreAuthorize("hasAnyAuthority('ADMIN', 'USER')")
    public ResponseEntity<?> addUserFavoriteMovie(@RequestBody MovieFavRequest movieRequest) {
        Authentication loggedInUser = SecurityContextHolder.getContext().getAuthentication();
        String username = loggedInUser.getName();
        User user = userService.getByUsername(username);
        return ResponseEntity.ok(userService.insertUserFavoriteMovie(user, movieRequest));
    }

    @DeleteMapping(Path.USER_FAVORITE)
    @PreAuthorize("hasAnyAuthority('ADMIN', 'USER')")
    public ResponseEntity<?> removeFavoriteMovie(@RequestBody MovieFavRequest movieRequest) {
        Authentication loggedInUser = SecurityContextHolder.getContext().getAuthentication();
        String username = loggedInUser.getName();
        User user = userService.getByUsername(username);
        return ResponseEntity.ok(userService.removeFavoriteMovie(user, movieRequest));
    }

    @PutMapping(Path.USER_ID)
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<User> updateUser(@PathVariable("id") Long id, @RequestBody User user) {
        return ResponseEntity.ok(userService.updateUser(id, user));
    }

    @PostMapping(Path.USER_PASSWORD)
    public ResponseEntity<?> changePassword(@RequestBody PasswordChangeModel passwordChangeModel) {
        Authentication loggedInUser = SecurityContextHolder.getContext().getAuthentication();
        String username = loggedInUser.getName();
        User user = userService.getByUsername(username);
        return ResponseEntity.ok(userService.changePassword(user, passwordChangeModel));
    }
}
