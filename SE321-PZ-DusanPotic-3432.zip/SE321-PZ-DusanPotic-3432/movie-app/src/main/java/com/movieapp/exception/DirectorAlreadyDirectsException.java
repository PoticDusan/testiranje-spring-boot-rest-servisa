package com.movieapp.exception;

public class DirectorAlreadyDirectsException extends RuntimeException {
    public DirectorAlreadyDirectsException(String message) {
        super(message);
    }
}
