package com.movieapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieAppApplication.class, args);

		System.out.println(
						"  ____                _       \n" +
						" |  _ \\ ___  __ _  __| |_   _ \n" +
						" | |_) / _ \\/ _` |/ _` | | | |\n" +
						" |  _ <  __/ (_| | (_| | |_| |\n" +
						" |_| \\_\\___|\\__,_|\\__,_|\\__, |\n" +
						"                        |___/ \n");

	}

}
