package com.movieapp.controller;

import com.movieapp.config.Path;
import com.movieapp.entity.Actor;
import com.movieapp.entity.Director;
import com.movieapp.entity.Movie;
import com.movieapp.model.MovieCastModel;
import com.movieapp.model.MovieDirectorModel;
import com.movieapp.model.MovieModel;
import com.movieapp.service.MovieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(Path.API)
public class MovieController {

    @Autowired
    private MovieService movieService;

    @GetMapping(Path.MOVIES)
    public List<Movie> getAllMovies() {
        return movieService.getMovies();
    }

    @GetMapping(Path.MOVIE_ID)
    public Movie getMovie(@PathVariable("id") Long id) {
        return movieService.getMovie(id);
    }

    @GetMapping(Path.MOVIE_FROM_YEAR)
    public List<Movie> getMoviesFromYear(@PathVariable("year") Integer year) {
        return movieService.getMoviesFromYear(year);
    }

    @GetMapping(Path.MOVIE_CAST)
    public List<Actor> getMovieCast(@PathVariable("id") Long id) {
        return movieService.getCast(id);
    }

    @GetMapping(Path.MOVIE_DIRECTORS)
    public List<Director> getMovieDirectors(@PathVariable("id") Long id) {
        return movieService.getDirectors(id);
    }

    @PostMapping(Path.MOVIE)
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<?> insertMovie(@RequestBody MovieModel movieModel) {
        return ResponseEntity.ok(movieService.insertMovie(movieModel));
    }

    @PostMapping(Path.MOVIE_DIRECTOR)
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<?> insertMovieDirector(@PathVariable("id") Long movieId, @RequestBody MovieDirectorModel movieDirectorModel) {
        return ResponseEntity.ok(movieService.insertMovieDirector(movieId, movieDirectorModel));
    }

    @DeleteMapping(Path.MOVIE_DIRECTOR)
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<?> removeMovieDirector(@PathVariable("id") Long movieId, @RequestBody MovieDirectorModel movieDirectorModel) {
        return ResponseEntity.ok(movieService.removeMovieDirector(movieId, movieDirectorModel));
    }

    @PostMapping(Path.MOVIE_ACTOR)
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<?> insertMovieActor(@PathVariable("id") Long movieId, @RequestBody MovieCastModel movieCastModel) {
        return ResponseEntity.ok(movieService.insertMovieActor(movieId, movieCastModel));
    }

    @DeleteMapping(Path.MOVIE_ACTOR)
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<?> removeMovieActor(@PathVariable("id") Long movieId, @RequestBody MovieCastModel movieCastModel) {
        return ResponseEntity.ok(movieService.removeMovieActor(movieId, movieCastModel));
    }

    @PutMapping(Path.MOVIE_ID)
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<Movie> updateMovie(@PathVariable("id") Long movieId, @RequestBody Movie movie) {
        return ResponseEntity.ok(movieService.updateMovie(movieId, movie));
    }
}
