package com.movieapp.service;

import com.movieapp.AbstractTest;
import com.movieapp.entity.Director;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

public class DirectorServiceTest extends AbstractTest {

    @Autowired
    private DirectorService directorService;

    @Override
    @Before
    public void setUp() {
        super.setUp();
    }

    @Test
    public void getDirectors() throws Exception {
        List<Director> directors = directorService.getDirectors();
        assertThat(directors).isNotNull().isNotEmpty();
    }

    @Test
    public void getDirectorNull() throws Exception {
        Director director = directorService.getDirector(999999L);
        assertThat(director).isNull();
    }

    @Test
    public void getDirectorNullNegative() throws Exception {
        Director director = directorService.getDirector(-1L);
        assertThat(director).isNull();
    }

    @Test
    public void getDirectorNotNull() throws Exception {
        Director director = directorService.getDirector(1L);
        assertThat(director).isNotNull();
    }

    @Test
    public void insertDirector() throws Exception {
        Director director = directorService.insertDirector(new Director("DirectorInsertFN", "DirectorInsertLN"));
        assertThat(director).isNotNull();
        assertThat(director.getId()).isNotNull();
    }

    @Test
    public void updateDirector() throws Exception {
        Director director = directorService.updateDirector(2L, new Director("DirectorNewFN", "DirectorNewLN"));
        assertThat(director).isNotNull();
        assertThat(director.getId()).isNotNull();
    }

}