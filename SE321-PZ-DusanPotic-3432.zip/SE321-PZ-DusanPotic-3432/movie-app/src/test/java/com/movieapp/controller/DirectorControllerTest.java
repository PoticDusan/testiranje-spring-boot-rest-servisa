package com.movieapp.controller;

import com.movieapp.AbstractTest;
import com.movieapp.entity.Director;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.junit.Assert.*;

public class DirectorControllerTest extends AbstractTest {

    @Override
    @Before
    public void setUp() {
        super.setUp();
    }

    @Test
    public void getAllDirectors() throws Exception {
        String uri = "/api/directors";
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.OK.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertNotEquals(content.length(), 0);
        Director[] directors = super.mapFromJson(content, Director[].class);
        assertTrue(directors.length > 0);
    }

    @Test
    public void getDirector() throws Exception {
        String uri = "/api/director/1";
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.OK.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertNotEquals(content.length(), 0);
        Director director = super.mapFromJson(content, Director.class);
        assertNotNull(director);
    }

    @Test
    @WithMockUser(authorities = "ADMIN")
    public void createDirector() throws Exception {
        String uri = "/api/director";
        Director director = new Director("DirTestFN", "DirTestLN");
        String directorJson = super.mapToJson(director);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(directorJson)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.CREATED.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertNotEquals(content.length(), 0);
        Director responseDirector = super.mapFromJson(content, Director.class);
        assertNotNull(responseDirector);
    }

    @Test
    @WithMockUser(authorities = "ADMIN")
    public void updateDirectorAllFields() throws Exception {
        String uri = "/api/director/1";
        Director director = new Director("UpdatedFN", "UpdatedLN");
        String directorJson = super.mapToJson(director);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.put(uri).contentType(MediaType.APPLICATION_JSON).content(directorJson)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.OK.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertNotEquals(content.length(), 0);
        Director responseDirector = super.mapFromJson(content, Director.class);
        assertNotNull(responseDirector);
        assertEquals(director.getFirstName(), responseDirector.getFirstName());
        assertEquals(director.getLastName(), responseDirector.getLastName());
    }

    @Test
    @WithMockUser(authorities = "ADMIN")
    public void updateActorFirstName() throws Exception {
        String uri = "/api/director/1";
        Director director = new Director();
        director.setFirstName("AnotherUpdatedFN");
        String directorJson = super.mapToJson(director);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.put(uri).contentType(MediaType.APPLICATION_JSON).content(directorJson)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.OK.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertNotEquals(content.length(), 0);
        Director responseDirector = super.mapFromJson(content, Director.class);
        assertNotNull(responseDirector);
        assertEquals(director.getFirstName(), responseDirector.getFirstName());
    }
}