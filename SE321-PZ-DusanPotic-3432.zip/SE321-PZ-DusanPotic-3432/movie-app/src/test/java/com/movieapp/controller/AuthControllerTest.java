package com.movieapp.controller;

import com.movieapp.AbstractTest;
import com.movieapp.entity.User;
import com.movieapp.model.UserRequest;
import com.movieapp.model.TokenResponse;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.junit.Assert.*;

public class AuthControllerTest extends AbstractTest {

    @Override
    @Before
    public void setUp() {
        super.setUp();
    }

    @Test
    public void authAdmin() throws Exception {
        String uri = "/api/auth";
        UserRequest userRequest = new UserRequest("petar123", "password");
        String jwtRequestJson = super.mapToJson(userRequest);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(jwtRequestJson)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.OK.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertNotEquals(content.length(), 0);
        TokenResponse tokenResponse = super.mapFromJson(content, TokenResponse.class);
        assertNotNull(tokenResponse);
    }

    @Test
    public void authUser() throws Exception {
        String uri = "/api/auth";
        UserRequest userRequest = new UserRequest("marko123", "password");
        String jwtRequestJson = super.mapToJson(userRequest);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(jwtRequestJson)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.OK.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertNotEquals(content.length(), 0);
        TokenResponse tokenResponse = super.mapFromJson(content, TokenResponse.class);
        assertNotNull(tokenResponse);
    }

    // BadCredentialsException
    @Test(expected = Exception.class)
    public void authInvalidCredentials() throws Exception {
        String uri = "/api/auth";
        UserRequest userRequest = new UserRequest("test", "password");
        String jwtRequestJson = super.mapToJson(userRequest);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(jwtRequestJson)).andReturn();
    }

    // UserExistsException
    @Test(expected = Exception.class)
    public void registerUsernameExists() throws Exception {
        String uri = "/api/register";
        UserRequest userRequest = new UserRequest("petar123", "P@ssc0de");
        String jwtRequestJson = super.mapToJson(userRequest);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(jwtRequestJson)).andReturn();
    }

    @Test
    public void registerUsernameDoesNotExists() throws Exception {
        String uri = "/api/register";
        UserRequest userRequest = new UserRequest("dusan123", "password");
        String jwtRequestJson = super.mapToJson(userRequest);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(jwtRequestJson)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.OK.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertNotEquals(content.length(), 0);
        User insertedUser = super.mapFromJson(content, User.class);
        assertNotNull(insertedUser);
    }
}