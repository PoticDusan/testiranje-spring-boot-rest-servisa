package com.movieapp.service;

import com.movieapp.AbstractTest;
import com.movieapp.entity.Actor;
import com.movieapp.entity.Movie;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

public class ActorServiceTest extends AbstractTest {

    @Autowired
    private ActorService actorService;

    @Override
    @Before
    public void setUp() {
        super.setUp();
    }

    @Test
    public void getActors() throws Exception {
        List<Actor> actors = actorService.getActors();
        assertThat(actors).isNotNull().isNotEmpty();
    }

    @Test
    public void getActorNull() throws Exception {
        Actor actor = actorService.getActor(999999L);
        assertThat(actor).isNull();
    }

    @Test
    public void getActorNullNegative() throws Exception {
        Actor actor = actorService.getActor(-1L);
        assertThat(actor).isNull();
    }

    @Test
    public void getActorNotNull() throws Exception {
        Actor actor = actorService.getActor(1L);
        assertThat(actor).isNotNull();
    }

    @Test
    public void getActorMoviesNotNullAndEmpty() throws Exception {
        List<Movie> actorMovies = actorService.getActorMovies(999999L);
        assertThat(actorMovies).isNotNull().isEmpty();
    }

    @Test
    public void getActorMoviesNotNullAndNotEmpty() throws Exception {
        List<Movie> actorMovies = actorService.getActorMovies(3L);
        assertThat(actorMovies).isNotNull().isNotEmpty();
    }

    @Test
    public void insertActor() throws Exception {
        Actor actor = actorService.insetActor(new Actor("ActorInsertFN", "ActorInsertLN"));
        assertThat(actor).isNotNull();
        assertThat(actor.getId()).isNotNull();
    }

    @Test
    public void updateActor() throws Exception {
        Actor actor = actorService.updateActor(5L, new Actor("NewFN", "NewLN"));
        assertThat(actor).isNotNull();
        assertThat(actor.getId()).isNotNull();
    }

}