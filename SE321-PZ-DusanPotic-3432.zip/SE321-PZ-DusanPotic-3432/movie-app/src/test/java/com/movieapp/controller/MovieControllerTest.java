package com.movieapp.controller;

import com.movieapp.AbstractTest;
import com.movieapp.entity.*;
import com.movieapp.model.MovieCastModel;
import com.movieapp.model.MovieDirectorModel;
import com.movieapp.model.MovieModel;
import com.movieapp.entity.Actor;
import com.movieapp.entity.Director;
import com.movieapp.entity.Movie;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.junit.Assert.*;

public class MovieControllerTest extends AbstractTest {

    @Override
    @Before
    public void setUp() {
        super.setUp();
    }

    @Test
    public void getAllMovies() throws Exception {
        String uri = "/api/movies";
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.OK.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertNotEquals(content.length(), 0);
        Movie[] movies = super.mapFromJson(content, Movie[].class);
        assertTrue(movies.length > 0);
    }

    @Test
    public void getExistingMovie() throws Exception {
        String uri = "/api/movie/1";
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.OK.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertNotEquals(content.length(), 0);
        Movie movie = super.mapFromJson(content, Movie.class);
        assertNotNull(movie);
    }

    @Test
    public void getNonExistingMovie() throws Exception {
        String uri = "/api/movie/999999";
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.OK.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertTrue(content.isEmpty());
    }

    @Test
    public void getMovieFromYearNotEmpty() throws Exception {
        String uri = "/api/movie/year/2012";
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.OK.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertNotEquals(content.length(), 0);
        Movie[] movies = super.mapFromJson(content, Movie[].class);
        assertTrue(movies.length > 0);
    }

    @Test
    public void getMovieFromYearEmpty() throws Exception {
        String uri = "/api/movie/year/9999";
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.OK.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertNotEquals(content.length(), 0);
        Movie[] movies = super.mapFromJson(content, Movie[].class);
        assertEquals(movies.length, 0);
    }

    @Test
    public void getMovieCastEmpty() throws Exception {
        String uri = "/api/movie/999999/cast";
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.OK.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertNotEquals(content.length(), 0);
        Actor[] actors = super.mapFromJson(content, Actor[].class);
        assertEquals(actors.length, 0);
    }

    @Test
    public void getMovieCastNotEmpty() throws Exception {
        String uri = "/api/movie/1/cast";
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.OK.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertNotEquals(content.length(), 0);
        Actor[] actors = super.mapFromJson(content, Actor[].class);
        assertTrue(actors.length > 0);
    }

    @Test
    public void getMovieDirectorsEmpty() throws Exception {
        String uri = "/api/movie/999999/directors";
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.OK.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertNotEquals(content.length(), 0);
        Director[] directors = super.mapFromJson(content, Director[].class);
        assertEquals(directors.length, 0);
    }

    @Test
    public void getMovieDirectorsNotEmpty() throws Exception {
        String uri = "/api/movie/1/directors";
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.OK.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertNotEquals(content.length(), 0);
        Director[] directors = super.mapFromJson(content, Director[].class);
        assertTrue(directors.length > 0);
    }

    // GenreNotFoundException
    @Test(expected = Exception.class)
    @WithMockUser(authorities = "ADMIN")
    public void insertMovieInvalidGenre() throws Exception {
        String uri = "/api/movie";
        Long genreId = 999999L;
        MovieModel movieModel = new MovieModel("Jaws", "When a killer shark unleashes chaos on a beach community, it's up to a local sheriff, a marine biologist, and an old seafarer to hunt the beast down.", 1975, 8.0F, genreId);
        String movieJson = super.mapToJson(movieModel);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(movieJson)).andReturn();
    }

    @Test
    @WithMockUser(authorities = "ADMIN")
    public void insertMovieValidGenre() throws Exception {
        String uri = "/api/movie";
        Long genreId = 2L;
        MovieModel movieModel = new MovieModel("Jaws", "When a killer shark unleashes chaos on a beach community, it's up to a local sheriff, a marine biologist, and an old seafarer to hunt the beast down.", 1975, 8.0F, genreId);
        String movieJson = super.mapToJson(movieModel);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(movieJson)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.OK.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertNotEquals(content.length(), 0);
        Movie responseMovie = super.mapFromJson(content, Movie.class);
        assertNotNull(responseMovie);
    }

    // DirectorAlreadyDirectsException
    @Test(expected = Exception.class)
    @WithMockUser(authorities = "ADMIN")
    public void insertMovieDirectorAlreadyExists() throws Exception {
        String uri = "/api/movie/1/director";
        MovieDirectorModel movieDirectorModel = new MovieDirectorModel(1L);
        String movieDMJson = super.mapToJson(movieDirectorModel);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(movieDMJson)).andReturn();
    }

    // MovieNotFoundException
    @Test(expected = Exception.class)
    @WithMockUser(authorities = "ADMIN")
    public void insertNotExistingMovieDirector() throws Exception {
        String uri = "/api/movie/999999/director";
        Long directorId = 4L;
        MovieDirectorModel movieDirectorModel = new MovieDirectorModel(directorId);
        String movieDMJson = super.mapToJson(movieDirectorModel);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(movieDMJson)).andReturn();
    }

    // DirectorNotFoundException
    @Test(expected = Exception.class)
    @WithMockUser(authorities = "ADMIN")
    public void insertMovieNotExistingDirector() throws Exception {
        String uri = "/api/movie/1/director";
        Long directorId = 999999L;
        MovieDirectorModel movieDirectorModel = new MovieDirectorModel(directorId);
        String movieDMJson = super.mapToJson(movieDirectorModel);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(movieDMJson)).andReturn();
    }

    @Test
    @WithMockUser(authorities = "ADMIN")
    public void insertMovieDirector() throws Exception {
        String uri = "/api/movie/1/director";
        Long directorId = 4L;
        MovieDirectorModel movieDirectorModel = new MovieDirectorModel(directorId);
        String movieDMJson = super.mapToJson(movieDirectorModel);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(movieDMJson)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.OK.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertNotEquals(content.length(), 0);
        Movie responseMovie = super.mapFromJson(content, Movie.class);
        assertTrue(responseMovie.hasDirectorWithId(directorId));
    }

    // DirectorNotFoundException
    @Test(expected = Exception.class)
    @WithMockUser(authorities = "ADMIN")
    public void removeMovieNotExistingDirector() throws Exception {
        String uri = "/api/movie/1/director";
        Long directorId = 999999L;
        MovieDirectorModel movieDirectorModel = new MovieDirectorModel(directorId);
        String movieDMJson = super.mapToJson(movieDirectorModel);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.delete(uri).contentType(MediaType.APPLICATION_JSON).content(movieDMJson)).andReturn();
    }

    // MovieNotFoundException
    @Test(expected = Exception.class)
    @WithMockUser(authorities = "ADMIN")
    public void removeNotExistingMovieDirector() throws Exception {
        String uri = "/api/movie/999999/director";
        Long directorId = 1L;
        MovieDirectorModel movieDirectorModel = new MovieDirectorModel(directorId);
        String movieDMJson = super.mapToJson(movieDirectorModel);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.delete(uri).contentType(MediaType.APPLICATION_JSON).content(movieDMJson)).andReturn();
    }

    @Test
    @WithMockUser(authorities = "ADMIN")
    public void removeMovieDirector() throws Exception {
        String uri = "/api/movie/1/director";
        Long directorId = 2L;
        MovieDirectorModel movieDirectorModel = new MovieDirectorModel(directorId);
        String movieDMJson = super.mapToJson(movieDirectorModel);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.delete(uri).contentType(MediaType.APPLICATION_JSON).content(movieDMJson)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.OK.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertNotEquals(content.length(), 0);
        Movie responseMovie = super.mapFromJson(content, Movie.class);
        assertFalse(responseMovie.hasDirectorWithId(directorId));
    }

    // MovieDirectorNotFoundException
    @Test(expected = Exception.class)
    @WithMockUser(authorities = "ADMIN")
    public void removeMovieDirectorNotDirecting() throws Exception {
        String uri = "/api/movie/2/director";
        Long directorId = 2L;
        MovieDirectorModel movieDirectorModel = new MovieDirectorModel(directorId);
        String movieDMJson = super.mapToJson(movieDirectorModel);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.delete(uri).contentType(MediaType.APPLICATION_JSON).content(movieDMJson)).andReturn();;
    }

    // ActorAlreadyInMovieException
    @Test(expected = Exception.class)
    @WithMockUser(authorities = "ADMIN")
    public void insertMovieActorAlreadyExists() throws Exception {
        String uri = "/api/movie/2/actor";
        MovieCastModel movieCastModel = new MovieCastModel(4L);
        String movieCMJson = super.mapToJson(movieCastModel);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(movieCMJson)).andReturn();
    }

    // MovieNotFoundException
    @Test(expected = Exception.class)
    @WithMockUser(authorities = "ADMIN")
    public void insertNotExistingMovieActor() throws Exception {
        String uri = "/api/movie/999999/actor";
        Long actorId = 6L;
        MovieCastModel movieCastModel = new MovieCastModel(actorId);
        String movieCMJson = super.mapToJson(movieCastModel);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(movieCMJson)).andReturn();
    }

    // ActorNotFoundException
    @Test(expected = Exception.class)
    @WithMockUser(authorities = "ADMIN")
    public void insertMovieNotExistingActor() throws Exception {
        String uri = "/api/movie/1/actor";
        Long actorId = 999999L;
        MovieCastModel movieCastModel = new MovieCastModel(actorId);
        String movieCMJson = super.mapToJson(movieCastModel);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(movieCMJson)).andReturn();
    }

    @Test
    @WithMockUser(authorities = "ADMIN")
    public void insertMovieActor() throws Exception {
        String uri = "/api/movie/1/actor";
        Long actorId = 6L;
        MovieCastModel movieCastModel = new MovieCastModel(actorId);
        String movieCMJson = super.mapToJson(movieCastModel);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(movieCMJson)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.OK.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertNotEquals(content.length(), 0);
        Movie responseMovie = super.mapFromJson(content, Movie.class);
        assertTrue(responseMovie.hasActorWithId(actorId));
    }

    // ActorNotFoundException
    @Test(expected = Exception.class)
    @WithMockUser(authorities = "ADMIN")
    public void removeMovieNotExistingActor() throws Exception {
        String uri = "/api/movie/1/actor";
        Long actorId = 999999L;
        MovieCastModel movieCastModel = new MovieCastModel(actorId);
        String movieCMJson = super.mapToJson(movieCastModel);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.delete(uri).contentType(MediaType.APPLICATION_JSON).content(movieCMJson)).andReturn();
    }

    // MovieNotFoundException
    @Test(expected = Exception.class)
    @WithMockUser(authorities = "ADMIN")
    public void removeNotExistingMovieActor() throws Exception {
        String uri = "/api/movie/999999/actor";
        Long actorId = 1L;
        MovieCastModel movieCastModel = new MovieCastModel(actorId);
        String movieCMJson = super.mapToJson(movieCastModel);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.delete(uri).contentType(MediaType.APPLICATION_JSON).content(movieCMJson)).andReturn();
    }

    @Test
    @WithMockUser(authorities = "ADMIN")
    public void removeMovieActor() throws Exception {
        String uri = "/api/movie/1/actor";
        Long actorId = 1L;
        MovieCastModel movieCastModel = new MovieCastModel(actorId);
        String movieCMJson = super.mapToJson(movieCastModel);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.delete(uri).contentType(MediaType.APPLICATION_JSON).content(movieCMJson)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.OK.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertNotEquals(content.length(), 0);
        Movie responseMovie = super.mapFromJson(content, Movie.class);
        assertFalse(responseMovie.hasActorWithId(actorId));
    }

    @Test
    @WithMockUser(authorities = "ADMIN")
    public void updateMovieAll() throws Exception {
        String uri = "/api/movie/2";
        Movie movie = new Movie("UpdatedName", "UpdatedCaption", 2000, 10.0F);
        String movieJson = super.mapToJson(movie);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.put(uri).contentType(MediaType.APPLICATION_JSON).content(movieJson)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.OK.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertNotEquals(content.length(), 0);
        Movie responseMovie = super.mapFromJson(content, Movie.class);
        assertNotNull(responseMovie);
    }

    @Test
    @WithMockUser(authorities = "ADMIN")
    public void updateMovieSome() throws Exception {
        String uri = "/api/movie/2";
        Movie movie = new Movie();
        movie.setName("NewMovieName");
        movie.setYear(1998);
        String movieJson = super.mapToJson(movie);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.put(uri).contentType(MediaType.APPLICATION_JSON).content(movieJson)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.OK.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertNotEquals(content.length(), 0);
        Movie responseMovie = super.mapFromJson(content, Movie.class);
        assertNotNull(responseMovie);
    }
}