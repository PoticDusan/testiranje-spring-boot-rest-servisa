package com.movieapp.controller;

import com.movieapp.AbstractTest;
import com.movieapp.entity.Genre;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.junit.Assert.*;

public class GenreControllerTest extends AbstractTest {

    @Override
    @Before
    public void setUp() {
        super.setUp();
    }

    @Test
    public void getAllGenres() throws Exception {
        String uri = "/api/genres";
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.OK.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertNotEquals(content.length(), 0);
        Genre[] genres = super.mapFromJson(content, Genre[].class);
        assertNotNull(genres);
        assertTrue(genres.length > 0);
    }

    @Test
    public void getGenre() throws Exception {
        String uri = "/api/genre/1";
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.OK.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertNotEquals(content.length(), 0);
        Genre genre = super.mapFromJson(content, Genre.class);
        assertNotNull(genre);
    }

    @Test
    @WithMockUser(authorities = "ADMIN")
    public void createGenre() throws Exception {
        String uri = "/api/genre";
        Genre genre = new Genre("TestGenre");
        String genreJson = super.mapToJson(genre);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(genreJson)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.CREATED.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertNotEquals(content.length(), 0);
        Genre responseGenre = super.mapFromJson(content, Genre.class);
        assertNotNull(responseGenre);
    }

    @Test
    @WithMockUser(authorities = "ADMIN")
    public void updateGenre() throws Exception {
        String uri = "/api/genre/1";
        Genre genre = new Genre("UpdatedGenreName");
        String genreJson = super.mapToJson(genre);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.put(uri).contentType(MediaType.APPLICATION_JSON).content(genreJson)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.OK.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertNotEquals(content.length(), 0);
        Genre responseGenre = super.mapFromJson(content, Genre.class);
        assertNotNull(responseGenre);
        assertEquals(genre.getName(), responseGenre.getName());
    }

}