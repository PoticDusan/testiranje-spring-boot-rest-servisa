package com.movieapp.controller;

import com.movieapp.AbstractTest;
import com.movieapp.entity.Movie;
import com.movieapp.entity.User;
import com.movieapp.model.MovieFavRequest;
import com.movieapp.model.PasswordChangeModel;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.junit.Assert.*;

public class UserControllerTest extends AbstractTest {

    @Override
    @Before
    public void setUp() {
        super.setUp();
    }

    @Test
    @WithMockUser(authorities = "ADMIN")
    public void getAllUsers() throws Exception {
        String uri = "/api/users";
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.OK.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertNotEquals(content.length(), 0);
        User[] users = super.mapFromJson(content, User[].class);
        assertTrue(users.length > 0);
    }

    @Test
    @WithMockUser(authorities = "ADMIN")
    public void getNonExistingUser() throws Exception {
        String uri = "/api/user/999999";
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.OK.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertTrue(content.isEmpty());
    }

    @Test
    @WithMockUser(authorities = "ADMIN")
    public void getExistingUser() throws Exception {
        String uri = "/api/user/2";
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.OK.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertNotEquals(content.length(), 0);
        User user = super.mapFromJson(content, User.class);
        assertNotNull(user);
    }

    @Test
    @WithMockUser(authorities = "ADMIN")
    public void getUserFavoriteMovies() throws Exception {
        String uri = "/api/user/2/favorite";
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.OK.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertNotEquals(content.length(), 0);
        Movie[] movies = super.mapFromJson(content, Movie[].class);
        assertTrue(movies.length > 0);
    }

    @Test
    @WithMockUser(username = "marko123", authorities = "USER")
    public void getMyFavoriteMovies() throws Exception {
        String uri = "/api/user/favorite";
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.OK.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertNotEquals(content.length(), 0);
        Movie[] movies = super.mapFromJson(content, Movie[].class);
        assertTrue(movies.length > 0);
    }

    // MovieAlreadyInFavoriteException
    @Test(expected = Exception.class)
    @WithMockUser(username = "jovan123", authorities = "USER")
    public void addMyFavoriteMovieAlreadyExists() throws Exception {
        String uri = "/api/user/favorite";
        Long movieId = 1L;
        MovieFavRequest movieFavRequest = new MovieFavRequest(movieId);
        String movieFavRequestJson = super.mapToJson(movieFavRequest);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(movieFavRequestJson)).andReturn();
    }

    // MovieNotFoundException
    @Test(expected = Exception.class)
    @WithMockUser(username = "jovan123", authorities = "USER")
    public void addMyFavoriteNonExistingMovie() throws Exception {
        String uri = "/api/user/favorite";
        Long movieId = 999999L;
        MovieFavRequest movieFavRequest = new MovieFavRequest(movieId);
        String movieFavRequestJson = super.mapToJson(movieFavRequest);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(movieFavRequestJson)).andReturn();
    }

    @Test
    @WithMockUser(username = "jovan123", authorities = "USER")
    public void addMyFavoriteMovie() throws Exception {
        String uri = "/api/user/favorite";
        Long movieId = 2L;
        MovieFavRequest movieFavRequest = new MovieFavRequest(movieId);
        String movieFavRequestJson = super.mapToJson(movieFavRequest);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(movieFavRequestJson)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.OK.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertNotEquals(content.length(), 0);
        Movie movie = super.mapFromJson(content, Movie.class);
        assertNotNull(movie);
    }

    // MovieNotInFavoriteListException
    @Test(expected = Exception.class)
    @WithMockUser(username = "petar123")
    public void removeNonExistingFavoriteMovie() throws Exception {
        String uri = "/api/user/favorite";
        Long movieId = 1L;
        MovieFavRequest movieFavRequest = new MovieFavRequest(movieId);
        String movieFavRequestJson = super.mapToJson(movieFavRequest);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.delete(uri).contentType(MediaType.APPLICATION_JSON).content(movieFavRequestJson)).andReturn();
    }

    @Test
    @WithMockUser(username = "marko123", authorities = "USER")
    public void removeMyFavoriteMovie() throws Exception {
        String uri = "/api/user/favorite";
        Long movieId = 1L;
        MovieFavRequest movieFavRequest = new MovieFavRequest(movieId);
        String movieFavRequestJson = super.mapToJson(movieFavRequest);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.delete(uri).contentType(MediaType.APPLICATION_JSON).content(movieFavRequestJson)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.OK.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertNotEquals(content.length(), 0);
        Movie movie = super.mapFromJson(content, Movie.class);
        assertNotNull(movie);
    }

    @Test
    @WithMockUser(authorities = "ADMIN")
    public void updateUserAllFields() throws Exception {
        String uri = "/api/user/1";
        User user = new User("username1234", "somepassword");
        String userJson = super.mapToJson(user);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.put(uri).contentType(MediaType.APPLICATION_JSON).content(userJson)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.OK.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertNotEquals(content.length(), 0);
        User responseUser = super.mapFromJson(content, User.class);
        assertNotNull(responseUser);
        assertEquals(user.getUsername(), responseUser.getUsername());
        assertNotEquals(user.getPassword(), responseUser.getPassword());
    }

    @Test
    @WithMockUser(authorities = "ADMIN")
    public void updateUserUsername() throws Exception {
        String uri = "/api/user/1";
        User user = new User();
        user.setUsername("newusername123");
        String userJson = super.mapToJson(user);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.put(uri).contentType(MediaType.APPLICATION_JSON).content(userJson)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.OK.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertNotEquals(content.length(), 0);
        User responseUser = super.mapFromJson(content, User.class);
        assertNotNull(responseUser);
        assertEquals(user.getUsername(), responseUser.getUsername());
    }

    @Test
    @WithMockUser(authorities = "ADMIN")
    public void updateUserPassword() throws Exception {
        String uri = "/api/user/1";
        User user = new User();
        user.setPassword("newpassword");
        String userJson = super.mapToJson(user);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.put(uri).contentType(MediaType.APPLICATION_JSON).content(userJson)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.OK.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertNotEquals(content.length(), 0);
        User responseUser = super.mapFromJson(content, User.class);
        assertNotNull(responseUser);
        assertNotEquals(user.getPassword(), responseUser.getPassword());
    }

    // InvalidOldPasswordException
    @Test(expected = Exception.class)
    @WithMockUser(username = "jovan123", authorities = "USER")
    public void changePasswordNotMatches() throws Exception {
        String uri = "/api/user/password";
        String wrongPassword = "wrongpassword";
        String newPassword = "newpassword";
        PasswordChangeModel passwordChangeModel = new PasswordChangeModel(wrongPassword, newPassword);
        String passwordChangeJson = super.mapToJson(passwordChangeModel);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(passwordChangeJson)).andReturn();
    }

    @Test
    @WithMockUser(username = "jovan123", authorities = "USER")
    public void changePassword() throws Exception {
        String uri = "/api/user/password";
        String correctPassword = "password";
        String newPassword = "newpassword";
        PasswordChangeModel passwordChangeModel = new PasswordChangeModel(correctPassword, newPassword);
        String passwordChangeJson = super.mapToJson(passwordChangeModel);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(passwordChangeJson)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.OK.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertNotEquals(content.length(), 0);
        User responseUser = super.mapFromJson(content, User.class);
        assertNotNull(responseUser);
    }
}