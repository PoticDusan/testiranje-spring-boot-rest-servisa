package com.movieapp.service;

import com.movieapp.AbstractTest;
import com.movieapp.entity.Director;
import com.movieapp.entity.Movie;
import com.movieapp.entity.MovieDirector;
import com.movieapp.exception.DirectorAlreadyDirectsException;
import com.movieapp.exception.DirectorNotFoundException;
import com.movieapp.exception.MovieDirectorNotFoundException;
import com.movieapp.exception.MovieNotFoundException;
import com.movieapp.model.MovieDirectorModel;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import static org.assertj.core.api.Assertions.assertThat;

public class MovieDirectorServiceTest extends AbstractTest {

    @Autowired
    private MovieDirectorService movieDirectorService;

    @Autowired
    private MovieService movieService;

    @Autowired
    private DirectorService directorService;

    @Override
    @Before
    public void setUp(){ super.setUp();}

    @Test(expected = MovieDirectorNotFoundException.class)
    public void getByMovieAndActorNonExisting() throws Exception {
        Movie movie = movieService.getMovie(1L);
        assertThat(movie).isNotNull();
        Director director = directorService.getDirector(3L);
        assertThat(director).isNotNull();
        MovieDirector movieDirector = movieDirectorService.getByMovieAndDirector(movie, director);
    }

    @Test
    public void getByMovieAndDirectorExisting() throws  Exception{
        Movie movie = movieService.getMovie(2L);
        assertThat(movie).isNotNull();
        Director director = directorService.getDirector(4L);
        assertThat(director).isNotNull();
        MovieDirector directorOfMovie = movieDirectorService.getByMovieAndDirector(movie, director);
        assertThat(directorOfMovie).isNotNull();
    }

    @Test(expected = DirectorAlreadyDirectsException.class)
    public void insertMovieAndDirectorAlreadyExists() throws Exception{
        Long movieId =1L;
        Long directorID = 1L;
        MovieDirectorModel movieDirectorModel = new MovieDirectorModel(directorID);
        MovieDirector movieDirector = movieDirectorService.insert(movieId,movieDirectorModel);
    }

    @Test(expected = MovieNotFoundException.class)
    public void insertMovieNotFound() throws Exception {
        Long movieId = 999999L;
        Long directorId = 1L;
        MovieDirectorModel movieDirectorModel = new MovieDirectorModel(directorId);
        MovieDirector movieCast = movieDirectorService.insert(movieId, movieDirectorModel);
    }

    @Test(expected = DirectorNotFoundException.class)
    public void insertDirectorNotFound() throws Exception {
        Long movieId = 1L;
        Long directorId = 999999L;
        MovieDirectorModel movieDirectorModel = new MovieDirectorModel(directorId);
        MovieDirector movieCast = movieDirectorService.insert(movieId, movieDirectorModel);
    }

    @Test
    public void insertMovieAndDirector() throws Exception{
        Long movieId = 2L;
        Long directorId = 1L;
        MovieDirectorModel movieDirectorModel = new MovieDirectorModel(directorId);
        MovieDirector movieDirector = movieDirectorService.insert(movieId,movieDirectorModel);
        assertThat(movieDirector).isNotNull();
    }
}
