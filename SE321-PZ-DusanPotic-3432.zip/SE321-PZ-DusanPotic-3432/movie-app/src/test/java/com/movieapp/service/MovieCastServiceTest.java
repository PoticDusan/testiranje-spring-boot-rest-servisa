package com.movieapp.service;

import com.movieapp.AbstractTest;
import com.movieapp.entity.Actor;
import com.movieapp.entity.Movie;
import com.movieapp.entity.MovieCast;
import com.movieapp.exception.ActorAlreadyInMovieException;
import com.movieapp.exception.ActorNotFoundException;
import com.movieapp.exception.MovieCastNotFoundException;
import com.movieapp.exception.MovieNotFoundException;
import com.movieapp.model.MovieCastModel;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import static org.assertj.core.api.Assertions.assertThat;

public class MovieCastServiceTest extends AbstractTest {

    @Autowired
    private MovieCastService movieCastService;

    @Autowired
    private MovieService movieService;

    @Autowired
    private ActorService actorService;

    @Override
    @Before
    public void setUp() {
        super.setUp();
    }

    @Test(expected = MovieCastNotFoundException.class)
    public void getByMovieAndActorNonExisting() throws Exception {
        Movie movie = movieService.getMovie(1L);
        assertThat(movie).isNotNull();
        Actor actor = actorService.getActor(4L);
        assertThat(actor).isNotNull();
        MovieCast movieCast = movieCastService.getByMovieAndActor(movie, actor);
    }

    @Test
    public void getByMovieAndActorExisting() throws Exception {
        Movie movie = movieService.getMovie(2L);
        assertThat(movie).isNotNull();
        Actor actor = actorService.getActor(5L);
        assertThat(actor).isNotNull();
        MovieCast actorInMovie = movieCastService.getByMovieAndActor(movie, actor);
        assertThat(actorInMovie).isNotNull();
    }

    @Test(expected = ActorAlreadyInMovieException.class)
    public void insertAlreadyExists() throws Exception {
        Long movieId = 1L;
        Long actorId = 2L;
        MovieCastModel movieCastModel = new MovieCastModel(actorId);
        MovieCast movieCast = movieCastService.insert(movieId, movieCastModel);
    }

    @Test(expected = MovieNotFoundException.class)
    public void insertMovieNotFound() throws Exception {
        Long movieId = 999999L;
        Long actorId = 2L;
        MovieCastModel movieCastModel = new MovieCastModel(actorId);
        MovieCast movieCast = movieCastService.insert(movieId, movieCastModel);
    }

    @Test(expected = ActorNotFoundException.class)
    public void insertActorNotFound() throws Exception {
        Long movieId = 1L;
        Long actorId = 999999L;
        MovieCastModel movieCastModel = new MovieCastModel(actorId);
        MovieCast movieCast = movieCastService.insert(movieId, movieCastModel);
    }

    @Test
    public void insert() throws Exception {
        Long movieId = 1L;
        Long actorId = 5L;
        MovieCastModel movieCastModel = new MovieCastModel(actorId);
        MovieCast movieCast = movieCastService.insert(movieId, movieCastModel);
        assertThat(movieCast).isNotNull();
    }

}