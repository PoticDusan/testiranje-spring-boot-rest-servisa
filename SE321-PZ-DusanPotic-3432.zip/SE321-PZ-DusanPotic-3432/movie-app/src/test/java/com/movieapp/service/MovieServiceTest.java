package com.movieapp.service;

import com.movieapp.AbstractTest;
import com.movieapp.entity.Actor;
import com.movieapp.entity.Director;
import com.movieapp.entity.Movie;
import com.movieapp.entity.MovieDirector;
import com.movieapp.exception.*;
import com.movieapp.model.MovieCastModel;
import com.movieapp.model.MovieDirectorModel;
import com.movieapp.model.MovieModel;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

public class MovieServiceTest extends AbstractTest {

    @Autowired
    private MovieService movieService;

    @Autowired
    private GenreService genreService;

    @Override
    @Before
    public void setUp(){super.setUp();}

    @Test
    public void getMovies()throws Exception{
        List<Movie> movies = movieService.getMovies();
        assertThat(movies).isNotNull().isNotEmpty();
    }

    @Test
    public void getMovieNull() throws Exception{
        Movie movie =movieService.getMovie(999999L);
        assertThat(movie).isNull();
    }

    @Test
    public void getMovieNullNegative() throws Exception{
        Movie movie = movieService.getMovie(-1L);
        assertThat(movie).isNull();
    }

    @Test
    public void getMovieNotNull() throws Exception{
        Movie movie = movieService.getMovie(1L);
        assertThat(movie).isNotNull();
    }

    @Test
    public void  getMoviesFromYearNullAndEmpty()throws Exception{
        List<Movie> moviesFromYear = movieService.getMoviesFromYear(9999);
        assertThat(moviesFromYear).isNotNull().isEmpty();
    }

    @Test
    public void  getMoviesFromYearNotNullAndNotEmpty()throws Exception{
        List<Movie> moviesFromYear = movieService.getMoviesFromYear(2012);
        assertThat(moviesFromYear).isNotNull().isNotEmpty();
    }

    @Test
    public void getMovieCastNotNullAndNotEmpty()throws Exception{
        List<Actor> movieCast = movieService.getCast(1L);
        assertThat(movieCast).isNotNull().isNotEmpty();
    }

    @Test
    public void getMovieCastNotNullAndEmpty()throws Exception{
        List<Actor> movieCast = movieService.getCast(99999L);
        assertThat(movieCast).isNotNull().isEmpty();
    }

    @Test
    public void getMovieDirectorsNotNullAndNotEmpty() throws Exception{
        List<Director> movieDirectors = movieService.getDirectors(1L);
        assertThat(movieDirectors).isNotNull().isNotEmpty();
    }

    @Test
    public void getMovieDirectorsNotNullAndEmpty() throws Exception{
        List<Director> movieDirectors = movieService.getDirectors(99999L);
        assertThat(movieDirectors).isNotNull().isEmpty();
    }

    @Test
    public void insertMovieGenreNotNull() throws Exception {
        MovieModel movieModel = new MovieModel();
        movieModel.setName("Once Upon a Time in Hollywood");
        movieModel.setCaption("A faded television actor and his stunt double strive to " +
                "achieve fame and success in the film industry during the final years of" +
                " Hollywood's Golden Age in 1969 Los Angeles.");
        movieModel.setYear(2019);
        movieModel.setRating(7.7F);
        movieModel.setGenreId(1L);
        Movie movie = movieService.insertMovie(movieModel);
        assertThat(movie).isNotNull();
        assertThat(movie.getId()).isNotNull();
    }

    @Test(expected = GenreNotFoundException.class)
    public void insertMovieGenreNull() throws Exception {
        MovieModel movieModel = new MovieModel();
        movieModel.setName("Once Upon a Time in Hollywood");
        movieModel.setCaption("A faded television actor and his stunt double strive to " +
                "achieve fame and success in the film industry during the final years of" +
                " Hollywood's Golden Age in 1969 Los Angeles.");
        movieModel.setYear(2019);
        movieModel.setRating(7.7F);
        movieModel.setGenreId(99999L);
        Movie movie = movieService.insertMovie(movieModel);
    }

    @Test(expected = GenreNotFoundException.class)
    public void insertMovieGenreNullNegative() throws Exception {
        MovieModel movieModel = new MovieModel();
        movieModel.setName("Once Upon a Time in Hollywood");
        movieModel.setCaption("A faded television actor and his stunt double strive to " +
                "achieve fame and success in the film industry during the final years of" +
                " Hollywood's Golden Age in 1969 Los Angeles.");
        movieModel.setYear(2019);
        movieModel.setRating(7.7F);
        movieModel.setGenreId(-1L);
        Movie movie = movieService.insertMovie(movieModel);
    }

    @Test(expected = DirectorAlreadyDirectsException.class)
    public void insertMovieDirectorAlreadyExists()   throws Exception{
        Long movieId = 1L;
        Long directorId = 1L;
        MovieDirectorModel movieDirectorModel = new MovieDirectorModel(directorId);
        Movie movie = movieService.insertMovieDirector(movieId,movieDirectorModel);
    }

    @Test(expected = DirectorNotFoundException.class)
    public void insertMovieDirectorNonExists()   throws Exception{
        Long movieId = 1L;
        Long directorId = 99999L;
        MovieDirectorModel movieDirectorModel = new MovieDirectorModel(directorId);
        Movie movie = movieService.insertMovieDirector(movieId,movieDirectorModel);
    }

    @Test(expected = MovieNotFoundException.class)
    public void insertMovieNonExistsDirector()   throws Exception{
        Long movieId = 99999L;
        Long directorId = 1L;
        MovieDirectorModel movieDirectorModel = new MovieDirectorModel(directorId);
        Movie movie = movieService.insertMovieDirector(movieId,movieDirectorModel);
    }


    @Test(expected = ActorAlreadyInMovieException.class)
    public void insertMovieActorAlreadyExists()   throws Exception{
        Long movieId = 1L;
        Long actorId = 2L;
        MovieCastModel movieCastModel = new MovieCastModel(actorId);
        Movie movie = movieService.insertMovieActor(movieId,movieCastModel);
    }

    @Test(expected = ActorNotFoundException.class)
    public void insertMovieActorNonExists()   throws Exception{
        Long movieId = 1L;
        Long actorId = 9999L;
        MovieCastModel movieCastModel = new MovieCastModel(actorId);
        Movie movie = movieService.insertMovieActor(movieId,movieCastModel);
    }

    @Test(expected = MovieNotFoundException.class)
    public void insertMovieNonExistsActor()   throws Exception{
        Long movieId = 99999L;
        Long actorId = 1L;
        MovieCastModel movieCastModel = new MovieCastModel(actorId);
        Movie movie = movieService.insertMovieActor(movieId,movieCastModel);
    }

    @Test(expected = MovieNotFoundException.class)
    public void updateMovieNotExists() throws Exception{
        Long movieId = 99999L;
        Movie newMovie = new Movie();
        Movie updatedMovie = movieService.updateMovie(movieId,newMovie);
    }

    @Test
    public void updateMovie() throws Exception{
        Long movieId = 1L;
        Movie newMovie = new Movie("","",2012,10.0F);
        Movie updatedMovie =  movieService.updateMovie(movieId,newMovie);
        assertThat(updatedMovie).isNotNull();
        assertThat(updatedMovie.getId()).isNotNull();
    }

}
