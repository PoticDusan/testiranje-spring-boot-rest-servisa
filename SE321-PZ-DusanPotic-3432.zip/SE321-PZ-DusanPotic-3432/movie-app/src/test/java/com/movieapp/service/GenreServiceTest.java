package com.movieapp.service;

import com.movieapp.AbstractTest;
import com.movieapp.entity.Genre;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

public class GenreServiceTest extends AbstractTest {

    @Autowired
    private GenreService genreService;

    @Override
    @Before
    public void setUp() {
        super.setUp();
    }

    @Test
    public void getGenres() throws Exception {
        List<Genre> genres = genreService.getGenres();
        assertThat(genres).isNotNull().isNotEmpty();
    }

    @Test
    public void getGenreNull() throws Exception {
        Genre genre = genreService.getGenre(999999L);
        assertThat(genre).isNull();
    }

    @Test
    public void getGenreNullNegative() throws Exception {
        Genre genre = genreService.getGenre(-1L);
        assertThat(genre).isNull();
    }


    @Test
    public void getGenreNotNull() throws Exception {
        Genre genre = genreService.getGenre(4L);
        assertThat(genre).isNotNull();
    }

    @Test
    public void insertGenre() throws Exception {
        Genre genre = genreService.insertGenre(new Genre("GenreName"));
        assertThat(genre).isNotNull();
        assertThat(genre.getId()).isNotNull();
    }

    @Test
    public void updateGenre() throws Exception {
        Genre genre = genreService.updateGenre(1L, new Genre("GenreNew"));
        assertThat(genre).isNotNull();
        assertThat(genre.getId()).isNotNull();
    }
}