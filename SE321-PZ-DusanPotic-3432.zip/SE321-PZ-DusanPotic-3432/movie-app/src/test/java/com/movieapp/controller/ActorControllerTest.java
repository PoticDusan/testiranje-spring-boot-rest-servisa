package com.movieapp.controller;

import com.movieapp.AbstractTest;
import com.movieapp.entity.Actor;
import com.movieapp.entity.Movie;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.junit.Assert.*;

public class ActorControllerTest extends AbstractTest {

    @Override
    @Before
    public void setUp() {
        super.setUp();
    }

    @Test
    public void getAllActors() throws Exception {
        String uri = "/api/actors";
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.OK.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertNotEquals(content.length(), 0);
        Actor[] actors = super.mapFromJson(content, Actor[].class);
        assertTrue(actors.length > 0);
    }

    @Test
    public void getExistingActor() throws Exception {
        String uri = "/api/actor/1";
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.OK.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertNotEquals(content.length(), 0);
        Actor actor = super.mapFromJson(content, Actor.class);
        assertNotNull(actor);
    }

    @Test
    public void getNonExistingActor() throws Exception {
        String uri = "/api/actor/999999";
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.OK.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertTrue(content.isEmpty());
    }

    @Test
    public void getActorMovies() throws Exception {
        String uri = "/api/actor/1/movies";
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.OK.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertNotEquals(content.length(), 0);
        Movie[] movies = super.mapFromJson(content, Movie[].class);
        assertTrue(movies.length > 0);
    }

    @Test
    @WithMockUser(authorities = "ADMIN")
    public void createActor() throws Exception {
        String uri = "/api/actor";
        Actor actor = new Actor("TestFN", "TestLN");
        String actorJson = super.mapToJson(actor);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(actorJson)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.CREATED.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertNotEquals(content.length(), 0);
        Actor responseActor = super.mapFromJson(content, Actor.class);
        assertNotNull(responseActor);
    }

    @Test
    @WithMockUser(authorities = "ADMIN")
    public void updateActorAllFields() throws Exception {
        String uri = "/api/actor/1";
        Actor actor = new Actor("UpdatedFN", "UpdatedLN");
        String actorJson = super.mapToJson(actor);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.put(uri).contentType(MediaType.APPLICATION_JSON).content(actorJson)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.OK.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertNotEquals(content.length(), 0);
        Actor responseActor = super.mapFromJson(content, Actor.class);
        assertNotNull(responseActor);
        assertEquals(actor.getFirstName(), responseActor.getFirstName());
        assertEquals(actor.getLastName(), responseActor.getLastName());
    }

    @Test
    @WithMockUser(authorities = "ADMIN")
    public void updateActorFirstName() throws Exception {
        String uri = "/api/actor/1";
        Actor actor = new Actor();
        actor.setFirstName("AnotherUpdatedFN");
        String actorJson = super.mapToJson(actor);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.put(uri).contentType(MediaType.APPLICATION_JSON).content(actorJson)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(status, HttpStatus.OK.value());
        String content = mvcResult.getResponse().getContentAsString();
        assertNotEquals(content.length(), 0);
        Actor responseActor = super.mapFromJson(content, Actor.class);
        assertNotNull(responseActor);
        assertEquals(actor.getFirstName(), responseActor.getFirstName());
    }

}